Sample archive for the Terminal-Icons demo.
